import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output, signal } from '@angular/core';
import { Employee, AttendanceRecord, Payment } from '../../../services/attendance.service';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss'
})
export class DashboardComponent {
  @Input() employees: Employee[] = [];
  @Input() records: AttendanceRecord[] = [];
  @Input() allPayments: Payment[] = [];

  @Input() pendingCount = 0;

  @Output() refreshRequested = new EventEmitter<void>();
  @Output() employeeSelected = new EventEmitter<Employee>();
  @Output() markAttendance = new EventEmitter<Employee>();
  @Output() shareCredentialsRequested = new EventEmitter<Employee>();
  @Output() deleteEmployeeRequested = new EventEmitter<Employee>();

  readonly busy = signal(false);

  employeeEarned(employeeId: number): number {
    return this.records
      .filter(
        record =>
          record.employee_id === employeeId &&
          record.approval_status === 'approved'
      )
      .reduce(
        (total, record) => total + Number(record.earned_amount),
        0
      );
  }

  employeePaid(employeeId: number): number {
    return this.allPayments
      .filter(
        payment =>
          payment.employee_id === employeeId &&
          payment.status === 'completed'
      )
      .reduce(
        (total, payment) => total + Number(payment.amount),
        0
      );
  }

  employeeBalance(employeeId: number): number {
    return this.employeeEarned(employeeId) - this.employeePaid(employeeId);
  }

  approvedCount(): number {
    return this.records.filter(
      record => record.approval_status === 'approved'
    ).length;
  }

  totalOutstanding(): number {
    return this.records
      .filter(record => record.approval_status === 'approved')
      .reduce(
        (total, record) => total + Number(record.outstanding_amount),
        0
      );
  }

  currency(value: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value || 0);
  }

  refresh(): void {
    if (this.busy()) return;

    this.busy.set(true);
    this.refreshRequested.emit();

    // AppComponent controls the actual async loading.
    // Keep the component lightweight and reusable.
    setTimeout(() => this.busy.set(false), 300);
  }

  selectEmployee(employee: Employee): void {
    this.employeeSelected.emit(employee);
  }

  openAttendance(employee: Employee): void {
    this.markAttendance.emit(employee);
  }

  shareCredentials(employee: Employee): void {
    this.shareCredentialsRequested.emit(employee);
  }

  deleteEmployee(employee: Employee): void {
    this.deleteEmployeeRequested.emit(employee);
  }
}