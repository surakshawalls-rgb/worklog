import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.surakshagroup.surakshahub',
  appName: 'SURAKSHA HUB',
  webDir: 'dist/attendance-maintenance/browser'
};

export default config;
